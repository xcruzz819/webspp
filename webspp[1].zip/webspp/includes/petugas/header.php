
<!-- partial -->
<div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="?p=home">
              <i class="mdi mdi-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="?p=siswa">
              <i class="mdi mdi-account menu-icon"></i>
              <span class="menu-title">Data Siswa</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="?p=transaksi">
              <i class="mdi mdi-credit-card menu-icon"></i>
              <span class="menu-title">Transaksi</span>
            </a>
          </li>
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between flex-wrap">
                <div class="d-flex align-items-end flex-wrap">

                  