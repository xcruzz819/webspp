<?php 

require_once '../../config/Koneksi.php';

class Petugas extends Koneksi {
    public function getDataPetugas($id) {
        $query = mysqli_query($this->konek, "SELECT * FROM tb_petugas WHERE id_petugas = '" . $id . "'");
      
        return $query;
       }

public function getDataSwsByNIS($nis) {
    $query = mysqli_query($this->konek,"SELECT * FROM tb_siswa WHERE nis = '$nis'");

    return $query;
}

public function getDataSiswa() {
    $query = mysqli_query($this->konek, "SELECT * FROM tb_siswa INNER JOIN tb_spp ON tb_siswa.id_spp = tb_spp.id_spp ORDER BY nisn ASC");
  
    return $query;
   }

public function getBayarByNISN($nisn) {
    $query = mysqli_query($this->konek,"SELECT p.id_pembayaran,p.bulan_dibayar,s.tahun,s.nominal, p.tgl_bayar, p.keterangan, pt.nama_petugas FROM tb_pembayaran AS p INNER JOIN tb_spp AS s ON p.id_spp = s.id_spp LEFT JOIN tb_petugas AS pt ON p.id_petugas = pt.id_petugas WHERE p.nisn = '$nisn' ORDER BY p.id_pembayaran ASC");

    return $query;

}

public function getBayarById($id) {
    $query = mysqli_query($this->konek,"SELECT p.id_pembayaran,p.bulan_dibayar,s.tahun,s.nominal, p.tgl_bayar, p.keterangan, pt.nama_petugas FROM tb_pembayaran AS p INNER JOIN tb_spp AS s ON p.id_spp = s.id_spp LEFT JOIN tb_petugas AS pt ON p.id_petugas = pt.id_petugas WHERE p.id_pembayaran = '$id' ORDER BY p.id_pembayaran ASC");

    return $query;

}

public function prosesBayar($tgl_bayar, $id_petugas, $id_pembayaran) {
    $query = mysqli_query($this->konek,"UPDATE tb_pembayaran SET tgl_bayar = '$tgl_bayar', keterangan = 'Lunas', id_petugas = '$id_petugas' WHERE id_pembayaran = $id_pembayaran");

    return $query;
}

public function batalBayar($id_pembayaran) {
    $query = mysqli_query($this->konek,"UPDATE tb_pembayaran SET tgl_bayar = NULL, keterangan = 'Belum lunas', id_petugas = NULL WHERE id_pembayaran = '$id_pembayaran'");

    return $query;
    }




}