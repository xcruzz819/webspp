<div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Home</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <h1 class="card-title">Transaksi</h1>
                <hr>
    
<form method="GET" action="">
    <label>Masukkan NIS</label>
    <input  type="text" name="nis">
    <button class="btn btn-info btn-sm" type="submit" name="submit">Cari</button>
</form><br>


<?php

if (isset($_GET['nis']) && $_GET['nis'] != '') {
    $rows = $petugas->getDataSwsByNIS($_GET['nis']);

if ($rows->num_rows > 0) {
    
    foreach ($rows as $row) :
?>

<table>
    <tr>
        <th>NIS :</th>
        <th><?= $row['nis']; ?></th>
    </tr>
    <tr>
        <td>Nama Siswa :</td>
        <td><?= $row['nama_lengkap']; ?></td>
    </tr>
    <tr>
        <td>Kelas :</td>
        <td><?= $row['kelas']; ?></td>
    </tr>
    <tr>
        <td>Jurusan :</td>
        <td><?= $row['jurusan']; ?></td>
    </tr>
</table><br>

<?php endforeach;


?>
<br>
<?php 
    if (isset($_SESSION['pesan'])) {
        echo $_SESSION['pesan'];
        unset($_SESSION['pesan']);
    }
?>
<table class="table">
    <tr>
        <th>No</th>
        <th>Bulan</th>
        <th>Tahun</th>
        <th>Nominal</th>
        <th>Tgl.Bayar</th>
        <th>Keterangan</th>
        <th>Petugas</th>
        <th class="text-center">Aksi</th>
    </tr>


<?php 
    $no = 1;
    $bayar = $petugas->getBayarByNISN($row['nisn']);

    while($data = mysqli_fetch_assoc($bayar)) :
?>

        <tr>
            <td><?= $no++; ?></td>
            <td><?= $data['bulan_dibayar']; ?></td>
            <td><?= $data['tahun']; ?></td>
            <td><?= $data['nominal']; ?></td>
            <td><?= $data['tgl_bayar']; ?></td>
            <td><?= $data['keterangan']; ?></td>
            <td><?= $data['nama_petugas']; ?></td>
            <td class="text-center">
            <?php 
                if ($data['keterangan'] == 'Lunas') {
                    echo '<a class="btn btn-danger mr-2" href="proses-transaksi.php?act=batal&id='.$data['id_pembayaran'].'"><span class="mdi mdi-cancel"> Batal</a>  <a class="btn btn-warning" target="_blank" href="cetak-transaksi.php?nis='.$_GET['nis'].'&id='.$data['id_pembayaran'].'"><span class="mdi mdi-printer"> Cetak</span></a>';
                } else {
                    echo '<a class="btn btn-primary" href="proses-transaksi.php?act=bayar&id='.$data['id_pembayaran'].'">Bayar</a>';
                }
            ?>
            </td>
        </tr>

<?php  
    endwhile;      
    } else {
        $_SESSION['pesan'] = '<div><script>
            swal({
                        title: "Oops!",
                        text: "NIS tidak terdaftar!",
                        icon: "error",
                        button: "Ok"
                     })
            </script></div>';
            echo $_SESSION['pesan'];
            unset($_SESSION['pesan']);
    }
}
?>

</table>

