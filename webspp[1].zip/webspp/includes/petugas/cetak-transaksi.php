<?php 
session_start();

require 'Petugas.php';

if (!isset($_SESSION['id'])) {
    header('location: ../');
}

$petugas = new Petugas;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../vendors/style/style.css">
    <title>Cetak Transaksi Bulanan</title>
</head>
<body>
    <div class="cetak" id="cetak">
    <h1>Laporan Pembayaran SPP</h1><br>
    <hr>

    <?php 
    $data = $petugas->getDataSwsByNIS($_GET['nis']);
    $data_siswa = mysqli_fetch_assoc($data);

    ?>
    <table>
        <tr>
            <th>Nama Siswa</th>
            <td>:</td>
            <td><?= $data_siswa['nama_lengkap'];?></td>
        </tr>
        <tr>
            <th>NIS</th>
            <td>:</td>
            <td><?= $data_siswa['nis'];?></td>
        </tr>
        <tr>
            <th>Kelas</th>
            <td>:</td>
            <td><?= $data_siswa['kelas'];?></td>
        </tr>
        <tr>
            <th>Jurusan</th>
            <td>:</td>
            <td><?= $data_siswa['jurusan'];?></td>
        </tr>
    </table>
    <br>
    <table border='1' cellspacing="" cellpadding="4" width="100%">
        <tr>
            <th>No.</th>
            <th>Id Pembayaran</th>
            <th>Pembayaran Bulan</th>
            <th>Tgl. Bayar</th>
            <th>Nominal</th>
            <th>Keterangan</th>
        </tr>

        <?php 
        $no = 1;
        $data_bayar = $petugas->getBayarById($_GET['id']);
        
        foreach ($data_bayar as $row) :
        ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['id_pembayaran']; ?></td>
            <td><?= $row['bulan_dibayar']; ?></td>
            <td><?= $row['tgl_bayar']; ?></td>
            <td><?= $row['nominal']; ?></td>
            <td><?= $row['keterangan']; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <table width="100%">
            <tr>
                <td></td>
                <td width="200px">
                    <br>
                    <p>Depok, <?= date('d/m/y'); ?><br>
                        Petugas,
                    <br>
                    <br>
                    <br>
                <p>______________________</p>
                </td>
            </tr>
    </table>
</div>
    <button class="btn btn-primary ml-5" onclick="printDiv('cetak')">Cetak</button>
</body>
</html>

<script>
function printDiv(cetak) {
    var printContents = document.getElementById(cetak).innerHTML;
    var originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;

    window.print();
    document.body.innerHTML = originalContents
}

</script>