<div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Data Siswa</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                        <h2 class="card-title">Data Siswa</h2>
                        <hr>
<a class="btn btn-primary mb-3 rounded-sm" href="?p=tambah-siswa"><i class="mdi mdi-account-multiple-plus"></i> Tambah Siswa</a>
<br>
<?php 
    if (isset($_SESSION['pesan'])) {
        echo $_SESSION['pesan'];
        unset($_SESSION['pesan']);
    }
?>
<table id="example" class="table table-bordered data">
    <thead>
    <tr>
        <th>No </th>
        <th>NISN</th>
        <th>NIS</th>
        <th>Nama Lengkap</th>
        <th>Kelas</th>
        <th>Jurusan</th>
        <th>Tahun Ajaran</th>
        <th class="text-center">Aksi</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <?php 
        $no = 1;
        $sws = $admin->getDataSiswa();
          //  while($row = mysqli_fetch_assoc($sws)) :
            foreach ($sws as $row) :
        ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['nisn']; ?></td>
                <td><?= $row['nis']; ?></td>
                <td><?= $row['nama_lengkap']; ?></td>
                <td><?= $row['kelas']; ?></td>
                <td><?= $row['jurusan']; ?></td>
                <td><?= $row['tahun']?></td>
                <td class="text-center"><a class="btn btn-primary mr-2" href="?p=ubah-siswa&id=<?= $row['id_siswa'];?>"><i class="mdi mdi-pencil-box-outline"></i> Edit</a><a class="btn btn-danger" href="?p=hapus-siswa&id=<?= $row['nisn'];?>" onclick="return confirm('data akan dihapus, yakin?')"><i class="mdi mdi-delete-forever"></i> Hapus</a></td>
            </tr>
        <?php endforeach; ?>
    </tr>
    </tbody>
</table>