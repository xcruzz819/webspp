
<div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Laporan Pembayaran</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Laporan Pembayaran</h2>
                      <hr>
<div class="form">
  <form method="POST">
    <label>Tampilkan data dari tgl.</label> 
    <input type="date" class="input-group date form-control" name="tgl_awal" required>
    <label>sampai tgl.</label>
    <input class="input-group date form-control" type="date" name="tgl_akhir" required>
    <button class="btn btn-primary btn-md mt-2" type="submit" name="tampil"><i class="mdi mdi-eye"></i> Tampilkan</button>
    <!-- <input type="submit" class="btn btn-primary mt-4" name="tampil" value="Tampilkan"> -->
  </form>
</div>

<br/>
<table class="table table-bordered" id="tblData">
  <tr>
    <th>No.</th>
    <th>NISN</th>
    <th>Nama</th>
    <th>Jurusan</th>
    <th class="text-center">Kelas</th>
    <th>Tgl. Bayar</th>
    <th>Nominal</th>
  </tr>


  <?php
  if (isset($_POST['tampil'])) {
    $date1 = $_POST['tgl_awal'];
    $date2 = $_POST['tgl_akhir'];

    $data = $admin->getDataPembayaranPerPeriode($date1, $date2); 

    $no = 1;
    $total = 0;
    foreach ($data as $r):
      ?>

      <tr>
        <td><?= $no++; ?></td>
        <td><?= $r['nisn']; ?></td>
        <td><?= $r['nama_lengkap'];?></td>
        <td><?= $r['jurusan'];?></td>
        <td class="text-center"><?= $r['kelas'];?></td>
        <td><?= $r['tgl_bayar']; ?></td>
        <td><?= $r['nominal']; ?></td>
      </tr>
      <?php
      $total += $r['nominal'];
    endforeach;

    echo "<button onclick=\"tableHtmlToExcel('tblData');\" class=\"btn btn-success mb-2\" id=\"download\" ><span class=\"mdi mdi-download\"></span> Ekspor Ke Excel</button>
    ";
    ?>
  
<?php
  } else {
    echo "<tr><td colspan='7'><center>Tidak ada data</center></td></tr>";
    
  }
  ?>

</table>

  <script type="text/javascript">
 function tableHtmlToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
   
    filename = filename?filename+'.xls':'excel_data.xls';
   
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
   
        downloadLink.download = filename;
       
        downloadLink.click();
    }
}
</script>