<?php 
if (empty($_GET)) {
    include 'home.php';
} 

if (isset($_GET['p'])) {
    if ($_GET['p'] == 'siswa') {
        require 'data-siswa.php';
    } elseif($_GET['p'] == 'home') {
		require_once 'home.php'; 
	} elseif($_GET['p'] == 'siswa') {
		require_once 'data-siswa.php'; 
	} elseif($_GET['p'] == 'laporan') {
		require_once 'laporan-pembayaran.php'; 
	} elseif($_GET['p'] == 'petugas') {
        require 'petugas.php';
    } elseif($_GET['p'] == 'ubah-petugas') {
        require 'ubah-petugas.php';
    } elseif($_GET['p'] == 'spp') {
        require 'spp.php';
    } elseif($_GET['p'] == 'tambah-spp') {
        require 'tambah-spp.php';
    } elseif($_GET['p'] == 'tambah-petugas') {
        require 'tambah-petugas.php';
    } elseif ($_GET['p'] == 'hapus-petugas') {
         if ($admin->hapusDataPetugas($_GET['id'])) {

            echo "<script>window.location.href='?p=petugas'</script>";
            $_SESSION['pesan'] = '<script>
            swal({
                        title: "Sukses!",
                        text: "Data Petugas berhasil diHapus!",
                        icon: "success",
                        button: "Ok"
                     })
            </script>';
        } else {
            echo "<script>window.location.href='?p=petugas'</script>";
            $_SESSION['pesan'] = '<script>
            swal({
                        title: "Gagal!",
                        text: "Data Petugas Gagal diHapus!",
                        icon: "erro",
                        button: "Ok"
                     })
            </script>';
        }
    } elseif($_GET['p'] == 'tambah-siswa') {
        require 'tambah-siswa.php';
    }  elseif($_GET['p'] == 'ubah-siswa') {
        require 'ubah-siswa.php';
    }  elseif($_GET['p'] == 'hapus-siswa') {
         if ($admin->hapusDataSiswa($_GET['id'])) {
            $admin->hapusDataBayar($_GET['id']);
            echo "<script>window.location.href='?p=siswa'</script>";
            $_SESSION['pesan'] = '<script>
            swal({
                        title: "Sukses!",
                        text: "Data Siswa berhasil diHapus!",
                        icon: "success",
                        button: "Ok"
                     })
            </script>';
        } else {
            echo "<script>window.location.href='?p=siswa'</script>";
            $_SESSION['pesan'] = '<script>
            swal({
                        title: "Gagal!",
                        text: "Data Siswa Gagal diHapus!",
                        icon: "error",
                        button: "Ok"
                     })
            </script>';
        }
    } elseif($_GET['p'] == 'ubah-spp') {
        require 'ubah-spp.php';
    } elseif($_GET['p'] == 'hapus-spp') {
        if ($admin->hapusDataSPP($_GET['id'])) {
            echo "<script>window.location.href='?p=spp'</script>";
            $_SESSION['pesan'] = '<script>
            swal({
                        title: "Sukses!",
                        text: "Data SPP berhasil diHapus!",
                        icon: "success",
                        button: "Ok"
                     })
            </script>';
        } else {
            echo "<script>window.location.href='?p=spp'</script>";
            $_SESSION['pesan'] = '<script>
            swal({
                        title: "Gagal!",
                        text: "Data SPP gagal diHapus!",
                        icon: "error",
                        button: "Ok"
                     })
            </script>';
        }
    } elseif ($_GET['p'] == 'logout') {
        echo "<script>window.location.href='../../index.php';</script>";
        session_destroy();
    } else {
        include '404.php';
    }
}

    include 'footer.php';
?>
