<?php 

if (isset($_POST['submit'])) {
	if($admin->ubahDataSPP($_POST['tahun'],$_POST['nominal'],$_GET['id'])) 
	{
		echo "<script>window.location.href='?p=spp'</script>";
		$_SESSION['pesan'] = '<script>
            swal({
                        title: "Sukses!",
                        text: "Data SPP berhasil diubah!",
                        icon: "success",
                        button: "Ok"
                     })
            </script>';
	} else {
		echo "<script>window.location.href='?p=spp'</script>";
    $_SESSION['pesan'] = '<script>
            swal({
                        title: "Gagal!",
                        text: "Data SPP gagal diubah!",
                        icon: "error",
                        button: "Ok"
                     })
            </script>';
	}
}


if (isset($_GET['id'])) {
	$spp = $admin->getDataSPPbyId($_GET['id']);

	foreach ($spp as $row) :
	
?>
<div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Ubah SPP</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
					<h2 class="card-title">Ubah data SPP</h2>
						<hr>
<form method="post">
<label for="tahun">Tahun</label><br>
    <input class="form-control" type="text" name="tahun" id="tahun" placeholder="Tahun Ajaran.." value="<?= $row['tahun']; ?>" required><br>
<label for="nominal">Nominal</label><br>
    <input class="form-control" type="text" name="nominal" id="nominal" placeholder="Nominal" value="<?= $row['nominal']; ?>" required><br>
    <input class="btn btn-primary" type="submit" name="submit" value="Simpan">
    <a class="btn btn-danger" href="?p=spp">Batal</a>
</form>

<?php endforeach;

}
 ?>