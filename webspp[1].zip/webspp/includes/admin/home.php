<div class="d-flex">
                    <i class="mdi mdi-home text-muted hover-cursor"></i>
                    <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;Home</p>
                    <p class="text-primary mb-0 hover-cursor"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <h1 class="card-title">Home page</h1>
                <hr>
                <h1 class="mb-5 text-center">Selamat Datang <?= $row['nama_petugas'];?>!</h1>
                <?php 
                
                $sws = $admin->jumlahSiswa();
                $ptgs = $admin->jumlahPetugas();
                $spp = $admin->jumlahSPP();
                $dt_ptgs = $ptgs->fetch_assoc();
                $dt_spp = $spp->fetch_assoc();
                $dt_Sws = $sws->fetch_assoc();
                
                ?>
                <div class="row">
                  <div class="col-md-4"> 
                    <div class="card text-center">
                      <div class="card-body">
                        <div class="card-title">
                        <h4>Jumlah Siswa</h4>
                        </div>
                       <h2 class="m-5"><i class="mdi mdi-account menu-icon"></i> <?= $dt_Sws['jmlSiswa']; ?></h2>
                        <a href="?p=siswa" class="btn btn-primary btn-block">Check!</a>
                      </div>
                    </div>
                 </div>
                 <div class="col-md-4"> 
                    <div class="card text-center">
                      <div class="card-body">
                        <div class="card-title">
                        <h4>Data SPP</h4>
                        </div>
                       <h2 class="m-5"><i class="mdi mdi-table menu-icon"></i> <?= $dt_spp['jmlSPP']; ?></h2>
                        <a href="?p=spp" class="btn btn-primary btn-block">Check!</a>
                      </div>
                    </div>
                 </div>
                 <div class="col-md-4"> 
                    <div class="card text-center">
                      <div class="card-body">
                        <div class="card-title">
                        <h4>Jumlah Petugas</h4>
                        </div>
                       <h2 class="m-5"><i class="mdi mdi-account-key menu-icon"></i> <?= $dt_ptgs['jmlPetugas']; ?></h2>
                        <a href="?p=petugas" class="btn btn-primary btn-block">Check!</a>
                      </div>
                    </div>
                 </div>
                </div>
               

