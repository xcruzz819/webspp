<?php

require_once 'config/Koneksi.php';

class Proses extends Koneksi {
 public function loginPetugas($username, $password) {
  $query = mysqli_query($this->konek, "SELECT * FROM tb_petugas WHERE username = '" . $username . "' AND password = '" . $password . "'");

  return $query;
 }
}

